import React, { Component } from 'react';
//import Carousel from 'react-elastic-carousel';
//import img1 from "../assets/images/img1.png";
//import "../../addedplace.css";
//import {Navbar, Nav, NavDropdown, Container, Row, Col, Button} from "react-bootstrap";


export default class About extends Component {
 
  render () {
 
    return (
        <div>
     Welcome
      </div>
    )
  }
}
