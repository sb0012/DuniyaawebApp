import React from 'react'

const UploadPlaceImages = () => {
  return (
    <div>
      
    </div>
  )
}

export default UploadPlaceImages
