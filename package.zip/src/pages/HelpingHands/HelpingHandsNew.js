import React from 'react'
import {FaHandsHelping} from 'react-icons/fa'

const HelpingHNew = () => {
  return (
    <div>
      <h1>Helping Hands <FaHandsHelping/></h1>
    </div>
  )
}

export default HelpingHNew
