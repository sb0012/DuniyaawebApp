import React from 'react'

const Notification = () => {
  return (
    <div>
    <h1>
    Notification page
    </h1>
    </div>
  )
}

export default Notification;
